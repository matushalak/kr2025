# 0. Imports
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# Make plots a bit nicer (optional)
plt.rcParams["figure.figsize"] = (10, 5)
plt.rcParams["axes.grid"] = True


# 1. Load data

cdcl_path = "results_sat_cdcl.csv"
dpll_path = "results_sat_dpll_mat.csv"
ea_path   = "ea_hf_results_test.csv"

cdcl = pd.read_csv(cdcl_path)
dpll = pd.read_csv(dpll_path)
ea   = pd.read_csv(ea_path)

display(cdcl.head())
display(dpll.head())
display(ea.head())


# 2. Merge into a single DataFrame

merged = (
    cdcl.rename(columns={"time_sec": "time_cdcl", "solved": "solved_cdcl"})
    .merge(
        dpll.rename(columns={"time_sec": "time_dpll", "solved": "solved_dpll"}),
        on=["idx", "status"],
        suffixes=("", "_dpll"),
    )
    .merge(
        ea[["idx", "solved", "time_sec", "generations", "best_conflicts"]]
        .rename(columns={
            "solved": "solved_ea",
            "time_sec": "time_ea",
            "generations": "gens_ea",
            "best_conflicts": "conf_ea",
        }),
        on="idx"
    )
)

display(merged.head())


# ============================================
# 3. Summary table (success and runtimes)
# ============================================

summary = pd.DataFrame({
    "method": ["CDCL", "DPLL", "EA"],
    "success_rate": [
        merged["solved_cdcl"].mean(),
        merged["solved_dpll"].mean(),
        merged["solved_ea"].mean(),
    ],
    "time_mean": [
        merged.loc[merged["solved_cdcl"], "time_cdcl"].mean(),
        merged.loc[merged["solved_dpll"], "time_dpll"].mean(),
        merged.loc[merged["solved_ea"], "time_ea"].mean(),
    ],
    "time_median": [
        merged.loc[merged["solved_cdcl"], "time_cdcl"].median(),
        merged.loc[merged["solved_dpll"], "time_dpll"].median(),
        merged.loc[merged["solved_ea"], "time_ea"].median(),
    ],
})

print("Summary statistics:")
display(summary)


# ============================================
# 4. Runtime distribution per method (boxplot)
#     – log10 scale so methods are comparable
# ============================================

times_logx = [
    np.log10(merged.loc[merged["solved_cdcl"], "time_cdcl"]),
    np.log10(merged.loc[merged["solved_dpll"], "time_dpll"]),
    np.log10(merged.loc[merged["solved_ea"], "time_ea"]),
]
times_log = [
    merged.loc[merged["solved_cdcl"], "time_cdcl"],
    merged.loc[merged["solved_dpll"], "time_dpll"],
    merged.loc[merged["solved_ea"], "time_ea"],
]

plt.figure()
plt.boxplot(times_log, labels=["CDCL", "DPLL", "EA"])
plt.ylabel("log10 runtime (seconds)")
plt.title("Runtime distribution per method (100 test sudokus)")
plt.tight_layout()
plt.show()


# ============================================
# 5. Success rate bar chart
# ============================================

plt.figure(figsize=(6,3))
plt.bar(summary["method"], summary["success_rate"], width=0.40)
plt.ylim(0, 1.05)
plt.ylabel("Success rate")
plt.title("Success rate per method")
plt.tight_layout()
plt.show()


# ============================================
# 6. EA generations to solution (boxplot)
#     – only for puzzles EA actually solved
# ============================================

ea_solved = merged[merged["solved_ea"]]

plt.figure()
plt.boxplot(ea_solved["gens_ea"], labels=["EA"])
plt.ylabel("Generations to solution")
plt.title("EA generations needed (solved puzzles only)")
plt.tight_layout()
plt.show()


# ============================================
# 7. Per-puzzle runtime comparison (scatter)
#     – log y-axis, one color per method
# ============================================

plt.figure()
x = merged["idx"]
plt.scatter(x, merged["time_cdcl"], label="CDCL", s=20)
plt.scatter(x, merged["time_dpll"], label="DPLL", s=20)
plt.scatter(x, merged["time_ea"],   label="EA",   s=20)
plt.yscale("log")
plt.xlabel("Puzzle index")
plt.ylabel("Runtime (seconds, log scale)")
plt.title("Runtime per puzzle and method")
plt.legend()
plt.tight_layout()
plt.show()


# ============================================
# 8. Optional: inspect hardest / failed EA cases
# ============================================

hard_cases = merged[~merged["solved_ea"] | (merged["gens_ea"] > 1000)]
print("Hard / failed EA puzzles:")
display(hard_cases[["idx", "solved_ea", "time_ea", "gens_ea", "conf_ea"]])